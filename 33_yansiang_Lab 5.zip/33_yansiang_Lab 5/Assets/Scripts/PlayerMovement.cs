﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class PlayerMovement : MonoBehaviour
{
    public float speed;
    public float score;
    private float coin = 0;
    public Rigidbody playerRigidbody;
    public Text scoreText;
    void Start()
    {
        scoreText.text = "Coins Collected = " + score;
        coin = GameObject.FindGameObjectsWithTag("Coin").Length;
    }
    void FixedUpdate()
    {
        float MoveHorizontal = Input.GetAxis("Horizontal");
        float MoveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(MoveHorizontal, 0, MoveVertical);
        transform.Translate(movement * Time.deltaTime * speed);
    }
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Coin")
        {
            score++;
            scoreText.text = "Coins Collected = " + score;
            Destroy(collision.gameObject);
            if (score >= coin)
                Invoke("gamewin", 1);
        }
        else if (collision.gameObject.tag == "Hazard")
        {
            SceneManager.LoadScene("GameLose");
        }
    }
    void gamewin()
    {
        SceneManager.LoadScene("GameWin");
    }
}
